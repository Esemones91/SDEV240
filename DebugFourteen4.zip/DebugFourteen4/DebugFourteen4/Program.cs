﻿// Reads and writes serializable Student objects
using System;
using static System.Console;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

class DebugFourteen4
{
    static void Main()
    {
        const int END = 999;
        const string FILENAME = "Students.json";
        Student stu = new Student();

        try
        {
            // Writing to file
            using (StreamWriter outFile = new StreamWriter(FILENAME))
            {
                Write("Enter Student number or " + END + " to quit: ");
                stu.StuNum = Convert.ToInt32(ReadLine());

                while (stu.StuNum != END)
                {
                    Write("Enter last name: ");
                    stu.Name = ReadLine();

                    Write("Enter GPA: ");
                    stu.Gpa = Convert.ToDouble(ReadLine());

                    // Serialize student to JSON and write to file
                    string jsonString = JsonSerializer.Serialize(stu);
                    outFile.WriteLine(jsonString);

                    Write("Enter Student number or " + END + " to quit: ");
                    stu.StuNum = Convert.ToInt32(ReadLine());
                }
            }

            // Reading from file
            using (StreamReader inFile = new StreamReader(FILENAME))
            {
                WriteLine("\n{0,-5}{1,-12}{2,8}\n", "Num", "Name", "GPA");

                string line;
                while ((line = inFile.ReadLine()) != null)
                {
                    // Deserialize JSON string to Student object
                    stu = JsonSerializer.Deserialize<Student>(line);
                    WriteLine("{0,-5}{1,-12}{2,8}", stu.StuNum, stu.Name, stu.Gpa.ToString("F2"));
                }
            }
        }
        catch (IOException ioEx)
        {
            WriteLine("File error: " + ioEx.Message);
        }
        catch (JsonException jsonEx)
        {
            WriteLine("Serialization error: " + jsonEx.Message);
        }
        catch (Exception ex)
        {
            WriteLine("An error occurred: " + ex.Message);
        }
    }
}

public class Student
{
    public int StuNum { get; set; }
    public string Name { get; set; }

    private double gpa;
    private const double MINGPA = 0.0;
    private const double MAXGPA = 4.0;

    public double Gpa
    {
        get { return gpa; }
        set
        {
            if (value >= MINGPA && value <= MAXGPA)
                gpa = value;
            else
                gpa = 0;
        }
    }
}
